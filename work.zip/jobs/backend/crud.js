// Import Category model
const Category = require("./models/catagory");

// Create a new category
async function createCategory(name, image) {
  try {
    const category = new Category({ name, image });
    const newCategory = await category.save();
    return newCategory;
  } catch (error) {
    throw new Error("Could not create category");
  }
}

// Get all categories
async function getCategories() {
  try {
    const categories = await Category.find();
    return categories;
  } catch (error) {
    throw new Error("Could not fetch categories");
  }
}

// Get category by ID
async function getCategoryById(id) {
  try {
    const category = await Category.findById(id);
    return category;
  } catch (error) {
    throw new Error("Could not fetch category");
  }
}

// Update category
async function updateCategory(id, newName, newImage) {
  try {
    const category = await Category.findById(id);
    if (!category) {
      throw new Error("Category not found");
    }
    category.name = newName;
    category.image = newImage;
    const updatedCategory = await category.save();
    return updatedCategory;
  } catch (error) {
    throw new Error("Could not update category");
  }
}

// Delete category
async function deleteCategory(id) {
  try {
    const deletedCategory = await Category.findByIdAndDelete(id);
    return deletedCategory;
  } catch (error) {
    throw new Error("Could not delete category");
  }
}

module.exports = {
  createCategory,
  getCategories,
  getCategoryById,
  updateCategory,
  deleteCategory,
};
