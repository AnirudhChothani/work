// Import mongoose
const mongoose = require("mongoose");

// Define Schema for Category
const categorySchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  image: {
    type: String,
    required: true,
  },
});

// Create model for Category
const Category = mongoose.model("Category", categorySchema);

module.exports = Category;
