// Import necessary packages
const mongoose = require("mongoose");

// Define schema for client
const clientSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },
  role: {
    type: String,
    enum: ["client", "admin"],
    default: "client",
  },
});

// Define schema for admin
const adminSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },
  role: {
    type: String,
    enum: ["client", "admin"],
    default: "admin",
  },
});

// Create models for client and admin using the schemas
const Client = mongoose.model("Client", clientSchema);
const Admin = mongoose.model("Admin", adminSchema);

// Export models
module.exports = {
  Client,
  Admin,
};
