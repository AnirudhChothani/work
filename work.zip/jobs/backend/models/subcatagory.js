// Import Mongoose
const mongoose = require('mongoose');

// Define the subcategory schema
const subcategorySchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    required: true
  },
  image: {
    type: String,
    required: true
  },
  category: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Category', // This refers to the Category model/schema
    required: false
  }
});

// Create and export the Subcategory model
const Subcategory = mongoose.model('Subcategory', subcategorySchema);

module.exports = Subcategory;
