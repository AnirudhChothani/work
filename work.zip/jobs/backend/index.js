const express = require("express");
const mongoose = require("mongoose");
const authRoutes = require("./routes/authRoutes");
const bodyParser = require("body-parser");
const catRoutes = require("./routes/catRoutes");
const subCatRoutes = require("./routes/subCatRoutes");
const cors = require("cors");

const app = express();

// Middleware
app.use(express.json());

// cors
app.use(cors());

app.use(express.urlencoded());
// Connect to MongoDB
mongoose
  .connect("mongodb://localhost:27017/my_database", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("Error connecting to MongoDB:", err));
// Routes
app.use("/auth", authRoutes);
app.use("/catagory", catRoutes);
app.use("/subcatagory", subCatRoutes);

// Start server
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
