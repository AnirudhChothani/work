const express = require("express");
const router = express.Router();
const {
  createCategory,
  getCategories,
  getCategoryById,
  updateCategory,
  deleteCategory,
} = require("../crud");

// Create a new category
router.post("/", async (req, res) => {
  try {
    const { name, image } = req.body;
    const newCategory = await createCategory(name, image);
    res.status(201).json(newCategory);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get all categories
router.get("/", async (req, res) => {
  try {
    const categories = await getCategories();
    res.json(categories);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get category by ID
router.get("/:id", async (req, res) => {
  try {
    const category = await getCategoryById(req.params.id);
    if (!category) {
      return res.status(404).json({ message: "Category not found" });
    }
    res.json(category);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update category
router.patch("/:id", async (req, res) => {
  try {
    const { name, image } = req.body;
    const updatedCategory = await updateCategory(req.params.id, name, image);
    res.json(updatedCategory);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete category
router.delete("/:id", async (req, res) => {
  try {
    const deletedCategory = await deleteCategory(req.params.id);
    res.json(deletedCategory);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
