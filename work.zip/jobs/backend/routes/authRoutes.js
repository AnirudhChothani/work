const express = require("express");
const router = express.Router();
const { Client, Admin } = require("../models/cliAdm"); // Assuming you have your models defined in a separate file

// Register route for clients
router.post("/register/client", async (req, res) => {
  try {
    const { username, email, password } = req.body;
    const client = new Client({ email, username, password });
    await client.save();
    res.status(201).send({ message: "Client registered successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).send({ error: error.message });
  }
});

// Register route for admins
router.post("/register/admin", async (req, res) => {
  try {
    const { username, email, password } = req.body;
    const admin = new Admin({ username, email, password });
    await admin.save();
    res.status(201).send({ message: "Admin registered successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).send({ error: "Error registering admin" });
  }
});

// Login route for clients
router.post("/login/client", async (req, res) => {
  try {
    const { email, password } = req.body;
    const client = await Client.findOne({ email });
    if (!client || client.password !== password) {
      return res.status(401).send({ error: "Invalid email or password" });
    }
    res.send({ message: "Client logged in successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).send({ error: "Error logging in client" });
  }
});

// Login route for admins
router.post("/login/admin", async (req, res) => {
  try {
    const { email, password } = req.body;
    const admin = await Admin.findOne({ email });
    if (!admin || admin.password !== password) {
      return res.status(401).send({ error: "Invalid email or password" });
    }
    res.send({ message: "Admin logged in successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).send({ error: "Error logging in admin" });
  }
});

module.exports = router;
