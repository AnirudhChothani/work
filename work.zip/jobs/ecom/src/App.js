import React from 'react';

import Category from './components/catagorys';
import Layout from './components/layout';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './components/home';
import Subcategory from './components/subcatagory';



function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Layout />}>
          <Route index element={<Home/>}/>    
          <Route path='/catagory' element={<Category/>}/> 
          <Route path='/subcatagory' element={<Subcategory/>}/>
        </Route>
      </Routes>
    </BrowserRouter>
  );
}


export default App;
