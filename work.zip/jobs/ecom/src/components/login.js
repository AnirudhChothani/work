import React, { useState } from "react";
 import { useNavigate } from "react-router-dom";

const Login = ({ userType }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
   const navigate = useNavigate();

  const handleLogin = async () => {
    const loginRoute =
      userType === "client"
        ? `${process.env.REACT_APP_API_URL}/auth/login/client`
        : `${process.env.REACT_APP_API_URL}/auth/login/admin`;

    try {
      const response = await fetch(loginRoute, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      }).then(()=> navigate("/"));
      
      if (response.ok) {
        console.log(`${userType} logged in successfully`);
       
      } else {
        console.error(`Error logging in ${userType}`);
      }
    } catch (error) {
      console.error(`Error logging in ${userType}:`, error);
    }
  };
  
  return (
    <div>
      <h2>{userType === "client" ? "Client" : "Admin"} Login</h2>
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleLogin}>Login</button>
    </div>
  );
};

export default Login;
