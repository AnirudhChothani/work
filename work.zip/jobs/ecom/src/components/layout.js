import { Outlet } from "react-router";
import { Link } from "react-router-dom";
//import bg_video from "../video/background_video.mp4";
import "./LayoutCss.css";

export default function Layout() {
  return (
    <>
      <div class="container vh-100">
        <div class="row">
          <div class="col-2 border border-primary p-2">
            <Link className="navbar-brand" to="/">
           Home            </Link>
          </div>
          <div class="col-10 p-2 border border-dark d-flex justify-content-between">
            <Link className="nav-link ps-2" to="/catagory">
              Add
            </Link>
            <Link className="nav-link ps-2" to="/subcatagory">
             subCatagory
            </Link>
            <Link className="nav-link ps-2" to="/aboutUs">
              About Us
            </Link>
            <Link className="nav-link ps-2" to="/contact">
              Contact
            </Link>
          </div>
        </div>
        <div class="row h-50 ">
          <div class="col-10 align-self-center">
            
            <Outlet />
          </div>
        </div>
        </div>
    

    </>
  );
}
