import "./LayoutCss.css";
import React, { useState, useEffect } from "react";

export default function Home() {
  const [data, setData] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
 

  const fetchSubcategories = async () => {
    try {
      const response = await fetch(`${process.env.REACT_APP_API_URL}/subcatagory`);
      const data = await response.json();
      setSubcategories(data);
    } catch (error) {
      console.error('Error fetching subcategories:', error);
    }
  };


  useEffect(() => {
    fetchData();
    fetchSubcategories();
  }, []);
  const fetchData = async () => {
    try {
      const response = await fetch(`${process.env.REACT_APP_API_URL}/catagory`);
      if (!response.ok) {
        throw new Error("Failed to fetch data");
      }
      const jsonData = await response.json();
      setData(jsonData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  const sortByAtoZ = () => {
    const sorted = [...subcategories].sort((a, b) => a.name.localeCompare(b.name));
    setSubcategories(sorted);
  };
  return (
    <div class="container vh-100">
      <div class="row h-25 ">
        <div class="col-2 align-self-center font-weight-bold">
          <h1>Sofas</h1>
        </div>
        <div class="col-10 align-self-center">
          <div className="row flex-row flex-nowrap overflow-auto ">
            {data.map((item, index) => (
              <div key={index} className="col-md-2 ">
                <div className="card rounded-0 h-20">
                  <img
                    src={item.image}
                    className="card-img-top"
                    alt={item.name}
                  />
                  <div className="card-body align-self-center">
                    <h5 className="card-title">{item.name}</h5>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div class="container w-100 align-self-right">

      <button className="btn btn-primary " onClick={sortByAtoZ}>Sort by Name (A to Z)</button>
      </div>
      <div class="row h-75">
        <div class="col-3 border border-secondary">

          
        </div>
       
        <div class="col-9 border border-secondary">

          <div class="row flex-row flex-nowrap overflow-auto  h-50 p-2">
            
          {subcategories.map((subcategory, index) => (
              <div key={index} className="col-md-4 style{{width: 18rem}}">
                <div className="card rounded-0 h-100">
                  <img
                    src={subcategory.image}
                    className="card-img-top fixed-image"
                    alt={subcategory.name}
                  />
                  <div className="card-body align-self-center">
                    <h5 className="card-title">{subcategory.name}</h5>
                  </div>
                  <div className="card-body align-self-center">
                    <h5 className="card-title ">${subcategory.price}</h5>
                  </div>
                </div>
              </div>
            ))}

            </div>
           
          </div>
        </div>
      </div>
   
  );
}
