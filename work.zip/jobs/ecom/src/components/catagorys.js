import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Category = () => {
  const [categories, setCategories] = useState([]);
  const [name, setName] = useState("");
  const [image, setImage] = useState("");
  const [editingCategory, setEditingCategory] = useState(null); // State to hold currently edited category

  const navigate = useNavigate();
  const fetchCategories = async () => {
    try {
      const response = await fetch(`${process.env.REACT_APP_API_URL}/catagory`);
      if (!response.ok) {
        throw new Error("Failed to fetch categories");
      }
      const data = await response.json();
      setCategories(data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingCategory) {
        const response = await fetch(
          `${process.env.REACT_APP_API_URL}/catagory/${editingCategory._id}`,
          {
            method: "PATCH",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ name, image }),
          }
        ).then(() => navigate("/"));
        if (!response.ok) {
          throw new Error("Failed to update category");
        }
        setEditingCategory(null); // Reset editing state
      } else {
        const response = await fetch(
          `${process.env.REACT_APP_API_URL}/catagory`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ name, image }),
          }
        ).then(() => navigate("/"));

        if (!response.ok) {
          throw new Error("Failed to create category");
        }
      }
      // Reset form fields
      setName("");
      setImage("");
      // Refresh categories
      fetchCategories();
    } catch (error) {
      console.error(error);
    }
  };
  const handleDelete = async (id) => {
    try {
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/catagory/${id}`,
        {
          method: "DELETE",
        }
      ).then(() => navigate("/"));

      if (!response.ok) {
        throw new Error("Failed to delete category");
      }
      // Refresh categories
      setCategories(categories.filter((category) => category._id !== id));
    } catch (error) {
      console.error(error);
    }
  };

  const handleEdit = (category) => {
    // Set editing
    setEditingCategory(category);
    setName(category.name);
    setImage(category.image);
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  return (
    <div class="category">
      <h2>Categories</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Name:
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </label>
        <label>
          Image URL:
          <input
            type="text"
            value={image}
            onChange={(e) => setImage(e.target.value)}
          />
        </label>
        <button type="submit">
          {editingCategory ? "Update Category" : "Add Category"}
        </button>
      </form>
      <ul>
        {categories.map((category) => (
          <li key={category._id}>
            <strong>{category.name}</strong>
            {category.image}
            <button onClick={() => handleEdit(category)}>Edit</button>

            <button onClick={() => handleDelete(category._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Category;
