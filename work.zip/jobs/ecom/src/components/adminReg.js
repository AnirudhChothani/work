import React, { useState } from "react";

const AdminRegister = () => {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleRegister = async () => {
    // Make a POST request to the backend route '/register/admin' with username, email, and password
    try {
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/auth/register/admin`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ username, email, password }),
        }
      );
      if (response.ok) {
        console.log("Admin registered successfully");
      } else {
        console.error("Error registering admin");
      }
    } catch (error) {
      console.error("Error registering admin:", error);
    }
  };

  return (
    <div>
      <h2>Admin Registration</h2>
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleRegister}>Register</button>
    </div>
  );
};

export default AdminRegister;
