import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
const Subcategory = () => {
  const [subcategories, setSubcategories] = useState([]);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [image, setImage] = useState("");

  const [editingId, setEditingId] = useState(null);
  const navigate = useNavigate();
  useEffect(() => {
    fetchSubcategories();
  }, []);

  const fetchSubcategories = async () => {
    try {
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/subcatagory`
      );
      const data = await response.json();
      setSubcategories(data);
    } catch (error) {
      console.error("Error fetching subcategories:", error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/subcatagory`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            name,
            price,
            image,
          }),
        }
      ).then(() => navigate("/"));
      if (response.ok) {
        await fetchSubcategories();
        setName("");
        setPrice("");
        setImage("");
      } else {
        console.error("Error creating subcategory");
      }
    } catch (error) {
      console.error("Error creating subcategory:", error);
    }
  };

  const handleDelete = async (id) => {
    try {
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/subcatagory/${id}`,
        {
          method: "DELETE",
        }
      ).then(() => navigate("/"));
      if (response.ok) {
        await fetchSubcategories();
      } else {
        console.error("Error deleting subcategory");
      }
    } catch (error) {
      console.error("Error deleting subcategory:", error);
    }
  };

  const handleEdit = (subcategory) => {
    setEditingId(subcategory._id);
    setName(subcategory.name);
    setPrice(subcategory.price);
    setImage(subcategory.image);
  };

  const handleUpdate = async () => {
    try {
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/subcatagory/${editingId}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            name,
            price,
            image,
          }),
        }
      ).then(() => navigate("/"));
      if (response.ok) {
        await fetchSubcategories();
        setEditingId(null);
        setName("");
        setPrice("");
        setImage("");
      } else {
        console.error("Error updating subcategory");
      }
    } catch (error) {
      console.error("Error updating subcategory:", error);
    }
  };

  return (
    <div>
      <h2>Create Subcategory</h2>
      <form onSubmit={editingId ? handleUpdate : handleSubmit}>
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          type="number"
          placeholder="Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          required
        />
        <input
          type="text"
          placeholder="Image URL"
          value={image}
          onChange={(e) => setImage(e.target.value)}
          required
        />

        <button type="submit">{editingId ? "Update" : "Create"}</button>
      </form>
      <h2>Subcategories</h2>
      <ul>
        {subcategories.map((subcategory) => (
          <li key={subcategory._id}>
            {subcategory.name} - {subcategory.price} - {subcategory.image} -{" "}
            {subcategory.category}
            <button onClick={() => handleEdit(subcategory)}>Edit</button>
            <button onClick={() => handleDelete(subcategory._id)}>
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Subcategory;
